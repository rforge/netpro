plot.subnet <-
function (x, subnet.id, network, plot.names = TRUE, ...) {

  require(Rgraphviz)
  require(igraph)

  #print("Pick the subnet")
  #subnet.nodes <- get.subnet(x, subnet.id)  
  subnet.nodes <- get.subnets(x, level = NULL)[[subnet.id]]
  mynet <- network[subnet.nodes, subnet.nodes]
  #message("convert to matrix graph format")
  #myg <- new("graphAM", mynet, "undirected")
  #myg2 <-as(myg, "graphNEL")
  #print("plotttin")
  tmp <- plot.response(x = NULL, mynet, mybreaks = NULL, mypalette = NULL, colors = FALSE, maintext = paste("Subnetwork", subnet.id))

  mynet

}

