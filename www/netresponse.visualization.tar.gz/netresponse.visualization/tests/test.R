# Sanity check: do the sample means within each response, and estimated means correspond?

library(netresponse)
data(toydata)
model <- toydata$model

subnet.id <- "Subnet-2"
r2s <- response2sample(model, subnet.id, component.list = TRUE)
response.idx <- 2

nodes <- model@subnets[[subnet.id]]
response.samples <- r2s[[response.idx]]
sample.mean <- colMeans(model@datamatrix[response.samples, nodes])
estimated.mean <- model@models[[subnet.id]]$mu[response.idx,]
if (cor(sample.mean, estimated.mean) < 0.9) {warning("Suspiciously low
correlation between sample mean and estimated mean!")} else
{message("Test OK.")}

