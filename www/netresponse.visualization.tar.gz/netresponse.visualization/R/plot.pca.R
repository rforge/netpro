plot.pca <-
function (x, subnet.id, ...) {

  model <- x

  if (is.numeric(subnet.id)) {
    subnet.id <- paste("Subnet", subnet.id, sep = "-")
    warning("subnet.id given as numeric; converting to character: ", "Subnet-", subnet.id, sep="")
  }
  
  # subnet and model parameters
  subnet <- model@subnets[[subnet.id]]
       m <- get.model.parameters(model, subnet.id)
  
  # pick data (subnet only)
  dat <- matrix(model@datamatrix[, subnet], nrow(model@datamatrix))
  dat2 <- rbind(dat, m$mu)  
  dat.mean <- colMeans(dat)

  # center the data
  dat.centered <- t(t(dat2) - dat.mean)

  # PCA, two principal components
  pca <- princomp( dat.centered )

  # projection plane
  v <- as.matrix( pca$loadings[, 1:2] )
  
  # projected centroids (in PC space) for the detected components
  dat.pca <- dat.centered %*% v
  
  plot(dat.pca[1:nrow(dat), ], main = paste("PCA plot: subnetwork ", subnet.id, sep=""), xaxt = 'n', yaxt = 'n', xlab = "", ylab = "")
  for (i in 1:nrow(m$mu)) {
    points(as.matrix(t(dat.pca[nrow(dat)+i, ])), pch = 19, col = "red")
  }
}

