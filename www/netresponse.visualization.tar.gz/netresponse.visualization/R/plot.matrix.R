plot.matrix <- function (x, maintext, ...) {
		  
  # set color breakpoints and palette
  mybreaks <- set.breaks(1, interval = .02)
  mypalette <- colorRampPalette(c("blue", "black", "red"), space = "rgb")
  
  # compute differential expression in nodes with respect to the mean expression level for each gene
  ctrl.state <- colMeans(x)
  dmat <- t(t(x) - ctrl.state)

  # Color plot of the whole expression matrix, ordered by responses
  tmp <- plotMatrix.2way(dmat, mybreaks = mybreaks, maintext=maintext, cexlab=1, mypalette = mypalette)
}

