plotMatrix.2way <- function (mat, mybreaks = NULL, maintext = "", xlab = "", ylab = "", cexlab=1, mypalette = NULL, interval = .1, cex.main = 1, xaxis = FALSE, yaxis = TRUE, row.tick = 1, col.tick = 1, cex.axis = .9, limit.trunc = 0) {

  # mat: differential expression matrix to plot in two-color palette
  # interval: interval for palette color switches
    
  require(graph)
  require(RBGL)
  require(Rgraphviz)
  require(graphics)

    #bins <- check.bins(x, mybreaks)
    #mypalette(length(mybreaks) + 1)[bins]
	   
  if (length(mybreaks) == 0)  {
    m <- max(round(max(abs(mat)), limit.trunc) - interval, 0)
    mm <- m + interval/2
    vals <- seq(interval/2,mm,interval)
    # Set breaks evenly around zero
    mybreaks  <- c(-(m+1e6),c(-rev(vals),vals),m+1e6)
  }
		  
  if (length(mypalette)==0) {
    mypalette <- colorRampPalette(c("blue", "black", "red"),space = "rgb")
    my.colors <- mypalette(length(mybreaks)-1)
  } else {
    #my.colors <- mypalette(seq(0,1,length=length(mybreaks)-1))
    my.colors <- mypalette(length(mybreaks)-1)
  }
		      
  # transpose and revert row order to plot matrix in the same way it
  # appears in its numeric form
  image(t(mat[rev(seq(nrow(mat))),]), col = my.colors, xaxt='n', yaxt='n', zlim=range(mybreaks), breaks=mybreaks, main=maintext, xlab=xlab, ylab=ylab, cex.lab=cexlab,cex.main=cex.main)

  if (xaxis) {
      
    v <- seq(1, nrow(mat), row.tick) # take every nth index
    axis(2, at = seq(0,1,length = nrow(mat))[v], labels = rev(rownames(mat))[v], cex.axis=cex.axis, las=2)
    
  }
  
  if (yaxis) {    

    v <- seq(1, ncol(mat), col.tick) # take every nth index
    axis(1, at = seq(0,1,length = ncol(mat))[v], labels = colnames(mat)[v], cex.axis=cex.axis, las=2)

  }
    
  return(list(palette = my.colors, breaks = mybreaks))
      	  
}




check.bins <-
function (difexp, mybreaks) {

  # check color scale bin for each expression value
  bins <- c()
  for (i in 1:length(difexp)) {
    # which color bins are smaller than our difexp value
    # (for probet: i, mode:mode)
    inds <- which(difexp[[i]] > mybreaks)
    if (length(inds) == 0) {
      bins[[i]] <- 1
    } else if (length(inds) > 0)  {
      bins[[i]] <- max(inds) + 1
    }
  }	
  bins
}

