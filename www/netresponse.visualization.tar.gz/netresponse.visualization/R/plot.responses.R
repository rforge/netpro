plot.responses <-
function (x, subnet.id, nc = 3, plot.names = TRUE, plot.mode = "network", ...) {

  require(igraph)
  require(Rgraphviz)

  if (is.numeric(subnet.id)) {
    subnet.id <- paste("Subnet", subnet.id, sep = "-")
    warning("subnet.id given as numeric; converting to character: ", "Subnet-", subnet.id, sep="")
  }


  pars <- get.model.parameters(x, subnet.id)
  subnet.nodes <- get.subnets(x)[[subnet.id]]
		  
  mynet <- x@network[subnet.nodes, subnet.nodes]

  # set color breakpoints and palette
  mybreaks <- set.breaks(1, interval = .02)
  mypalette <- colorRampPalette(c("blue", "black", "red"), space = "rgb")
  
  # convert to matrix graph format
  #myg <- new("graphAM", mynet, "undirected")
  #myg2 <- as(myg, "graphNEL")

  # compute differential expression in nodes with respect to the mean expression level for each gene
  ctrl.state <- colMeans(x@datamatrix[, subnet.nodes])
  centroids <- t(pars$mu)
  difexp <- apply(centroids, 2, function(x){ x - ctrl.state })
  rownames(difexp) <- rownames(centroids)

  if (plot.mode == "network") {
    par(mfrow = c(ceiling(length(pars$w)/nc), nc))
    for (comp in 1:length(pars$w)) {
      tmp <- plot.response(difexp[,comp], mynet, mybreaks, mypalette, plot.names,
                          main = paste(subnet.id, "/Response-", comp, sep=""))
    }
  } else if (plot.mode == "matrix") {
    # order samples according to responses
    ordered.samples <- unlist(response2sample(x, subnet.id))

    dmat <- x@datamatrix[ordered.samples, subnet.nodes]
    dmat <- t(t(dmat) - ctrl.state)

    # Color plot of the whole expression matrix, ordered by responses
    tmp <- plotMatrix.2way(dmat, mybreaks = mybreaks, maintext = subnet.id, xlab="", ylab="", cexlab=1, mypalette)
  }

  list(breaks = mybreaks, palette = mypalette, info = tmp)

}

