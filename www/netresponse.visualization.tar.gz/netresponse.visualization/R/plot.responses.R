plot.responses <-
function (x, subnet.id, nc = 3, plot.names = TRUE, ...) {

  require(igraph)
  require(Rgraphviz)

  pars <- get.model.parameters(x, subnet.id)
  subnet.nodes <- get.subnets(x)[[subnet.id]]
		  
  mynet <- x@network[subnet.nodes, subnet.nodes]

  # set color breakpoints and palette
  mybreaks <- set.breaks(1, interval = .02)
  mypalette <- colorRampPalette(c("blue", "black", "red"), space = "rgb")
  
  # convert to matrix graph format
  #myg <- new("graphAM", mynet, "undirected")
  #myg2 <- as(myg, "graphNEL")

  # compute differential expression in nodes with respect to the mean expression level for each gene
  ctrl.state <- colMeans(x@datamatrix[, subnet.nodes])
  centroids <- t(pars$mu)
  difexp <- apply(centroids, 2, function(x){ x - ctrl.state })
  rownames(difexp) <- rownames(centroids)

  par(mfrow = c(ceiling(length(pars$w)/nc), nc))
  for (comp in 1:length(pars$w)) {
    tmp <- plot.response(difexp[,comp], mynet, mybreaks, mypalette, plot.names,
                         main = paste(subnet.id, "/ comp. ", comp, sep=" "))
  }

  list(breaks = mybreaks, palette = mypalette)

}

